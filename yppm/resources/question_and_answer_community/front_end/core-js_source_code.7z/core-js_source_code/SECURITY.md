# Security Policy

## Supported Versions

The [latest released version](https://github.com/zloirock/core-js/releases) of `core-js` is supported.

## Reporting a Vulnerability

To report a vulnerability please send an email with the details to zloirock@zloirock.ru. 
This will help us to assess the risk and start the necessary steps.

Thanks for helping to keep `core-js` secure!
