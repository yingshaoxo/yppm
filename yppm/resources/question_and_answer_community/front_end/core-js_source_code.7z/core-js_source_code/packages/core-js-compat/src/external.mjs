export default {
  modules: {
    bun: '0.1.1',
    chrome: '61',
    deno: '1.0',
    edge: '16',
    firefox: '60',
    node: '13.2',
    safari: '10.1',
  },
};
