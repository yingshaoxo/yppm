'use strict';
var defineProperty = require('../internals/object-define-property');

module.exports = function (target, name, descriptor) {
  return defineProperty.f(target, name, descriptor);
};
